﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace FieldValidator
{
    
    public partial class ConfigurationForm : Form
    {
        public string ActiveEnv;
        public List<Environments> configData;
        public Environments activeConfigData;
        public ConfigurationForm()
        {
            InitializeComponent();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            new ValidatorForm().Show();
        }

        private void ConfigurationForm_Load(object sender, EventArgs e)
        {
            
            
            setConfigData();
        }

        public XmlDocument GetAppConfig()
        {
            string sFile = Environment.CurrentDirectory + "\\FieldValidatorConfig.xml";

            if (!File.Exists(sFile))
            {
                return null;
            }

            XmlDocument objXmlDocument = new XmlDocument();

            objXmlDocument.Load(sFile);

            return objXmlDocument;
        }

        private void cmbEnv_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            setConfigData();
        }

        public void setConfigData()
        {

            List<Items> envNames = new List<Items>();
            configData = new List<Environments>();

            XmlNodeList objXmlNodeList = GetAppConfig().SelectNodes("Configuration/Environments/Environment");

            int count = 0;
            foreach (XmlNode node in objXmlNodeList)
            {
                count++;
                envNames.Add(new Items { ItemID = count, ItemName = node.SelectSingleNode("Name").InnerText });
                configData.Add(new Environments { Name = node.SelectSingleNode("Name").InnerText, ServerURL = node.SelectSingleNode("ServerURL").InnerText, UserName = node.SelectSingleNode("UserName").InnerText, Password = node.SelectSingleNode("Password").InnerText });
                if (count == 1) { ActiveEnv = node.SelectSingleNode("Name").InnerText; }
            }

            cmbEnv.ValueMember = "ItemID";
            cmbEnv.DisplayMember = "ItemName";
            cmbEnv.DataSource = envNames;

            activeConfigData = configData[cmbEnv.SelectedIndex];

            lblName.Text = activeConfigData.Name;
            lblServerURL.Text = activeConfigData.ServerURL;
            lblUserName.Text = activeConfigData.UserName;
            lblPassword.Text = "********";//activeConfigData.Password;
            if (checkHTTPPost())
            {
                lblstatus.Text = "success";
                lblstatus.ForeColor = Color.Green;
            }
            else
            {
                lblstatus.Text = "failure";
                lblstatus.ForeColor = Color.Red;
            }
        }

        public string HTTPPost(string requestXML)
        {
            string result = "";
            try
            {
                System.Net.HttpWebRequest webRequest = (System.Net.HttpWebRequest)System.Net.WebRequest.Create(activeConfigData.ServerURL);
                webRequest.Method = "POST";
                webRequest.ContentType = "text/xml"; webRequest.Timeout = 90000;
                string timeOut = System.Configuration.ConfigurationManager.AppSettings["TimeOut"];
                if (timeOut != null)
                {
                    webRequest.Timeout = Convert.ToInt32(timeOut);
                }
                webRequest.ServicePoint.ConnectionLimit = 10;
                string connectionLimit = System.Configuration.ConfigurationManager.AppSettings["ConnectionLimit"];
                if (connectionLimit != null)
                {
                    webRequest.ServicePoint.ConnectionLimit = Convert.ToInt32(connectionLimit);
                }
                byte[] byteArray = System.Text.Encoding.UTF8.GetBytes(requestXML);
                System.IO.Stream strm = webRequest.GetRequestStream();
                strm.Write(byteArray, 0, byteArray.Length);
                strm.Close();
                System.Net.WebResponse resp = webRequest.GetResponse();
                System.Text.Encoding enc = Encoding.GetEncoding("utf-8");
                System.IO.StreamReader reader = new System.IO.StreamReader(resp.GetResponseStream(), enc);
                result = reader.ReadToEnd();
                reader.Close();

            }
            catch (Exception ex)
            {
                

            }
            return result;
        }

        public Boolean checkHTTPPost()
        {
            Boolean status = false;
            

            try { 
                string reqXML = "<server><requests><Session.loginRq userName='{{user}}' password='{{pass}}' /><Session.closeRq /></requests></server>";
                reqXML=reqXML.Replace("{{user}}", activeConfigData.UserName);
                reqXML=reqXML.Replace("{{pass}}", activeConfigData.Password);

                string resp=HTTPPost(reqXML);
                XmlDocument xmlResp = new XmlDocument();
                xmlResp.LoadXml(resp);

                if (xmlResp.SelectSingleNode("server/responses/Session.loginRs/@status").Value == "success") { status = true; }
            
            }
            catch(Exception ex)
            {
                status = false;
            }

            return status;
        }

        public XmlDocument getFieldXML(string fieldID,string manuscript)
        {
            setConfigData();
            XmlDocument xmlResp = new XmlDocument();

            try
            {
                string reqXML = "<server><requests><Session.loginRq userName='{{user}}' password='{{pass}}' /><ManuScript.getFieldDetailRq fieldID='{{field}}' manuscript='{{MSID}}' /><ManuScript.getFullPathRq fieldID='{{field}}' manuscript='{{MSID}}' /><Session.closeRq /></requests></server>";
                reqXML = reqXML.Replace("{{user}}", activeConfigData.UserName);
                reqXML = reqXML.Replace("{{pass}}", activeConfigData.Password);
                reqXML = reqXML.Replace("{{field}}", fieldID);
                reqXML = reqXML.Replace("{{MSID}}", manuscript);

                string resp = HTTPPost(reqXML);
                
                xmlResp.LoadXml(resp);                

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString());

            }

            if (xmlResp.InnerXml.Contains("Session.loginRs status=\"failure\"")) {
                throw new Exception("Invalid username or password");
            }

            return xmlResp;
        }

        public XmlDocument getFieldAnnotationsXML(string fieldID, string manuscript)
        {
            setConfigData();
            XmlDocument xmlResp = new XmlDocument();

            try
            {
                string reqXML = "<server><requests><Session.loginRq userName='{{user}}' password='{{pass}}' /><ManuScript.getFieldAnnotationRq fieldID='{{field}}' manuscript='{{MSID}}' /><Session.closeRq /></requests></server>";
                reqXML = reqXML.Replace("{{user}}", activeConfigData.UserName);
                reqXML = reqXML.Replace("{{pass}}", activeConfigData.Password);
                reqXML = reqXML.Replace("{{field}}", fieldID);
                reqXML = reqXML.Replace("{{MSID}}", manuscript);

                string resp = HTTPPost(reqXML);

                xmlResp.LoadXml(resp);

            }
            catch (Exception ex)
            {

            }

            return xmlResp;
        }

    }

    public class Environments
    {
        public string Name{ get; set; }
        public string ServerURL{ get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
    }
}
