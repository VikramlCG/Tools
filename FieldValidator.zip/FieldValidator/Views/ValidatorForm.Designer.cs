﻿namespace FieldValidator
{
    partial class ValidatorForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtPL101path = new System.Windows.Forms.TextBox();
            this.lblPath = new System.Windows.Forms.Label();
            this.btnBrowse = new System.Windows.Forms.Button();
            this.lblFieldColumn = new System.Windows.Forms.Label();
            this.cmbFieldColumn = new System.Windows.Forms.ComboBox();
            this.cmbManuScriptColumn = new System.Windows.Forms.ComboBox();
            this.lblManuscriptColumn = new System.Windows.Forms.Label();
            this.btnValidate = new System.Windows.Forms.Button();
            this.cmbSheetName = new System.Windows.Forms.ComboBox();
            this.lblSheetName = new System.Windows.Forms.Label();
            this.lblheader1 = new System.Windows.Forms.Label();
            this.btnSettings = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtPL101path
            // 
            this.txtPL101path.Location = new System.Drawing.Point(42, 57);
            this.txtPL101path.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtPL101path.Name = "txtPL101path";
            this.txtPL101path.Size = new System.Drawing.Size(363, 23);
            this.txtPL101path.TabIndex = 0;
            this.txtPL101path.TextChanged += new System.EventHandler(this.txtPL101path_TextChanged);
            // 
            // lblPath
            // 
            this.lblPath.AutoSize = true;
            this.lblPath.Location = new System.Drawing.Point(42, 40);
            this.lblPath.Name = "lblPath";
            this.lblPath.Size = new System.Drawing.Size(65, 15);
            this.lblPath.TabIndex = 1;
            this.lblPath.Text = "PL101 Path";
            // 
            // btnBrowse
            // 
            this.btnBrowse.Location = new System.Drawing.Point(42, 82);
            this.btnBrowse.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.Size = new System.Drawing.Size(82, 22);
            this.btnBrowse.TabIndex = 2;
            this.btnBrowse.Text = "Browse";
            this.btnBrowse.UseVisualStyleBackColor = true;
            this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click);
            // 
            // lblFieldColumn
            // 
            this.lblFieldColumn.AutoSize = true;
            this.lblFieldColumn.Location = new System.Drawing.Point(42, 230);
            this.lblFieldColumn.Name = "lblFieldColumn";
            this.lblFieldColumn.Size = new System.Drawing.Size(78, 15);
            this.lblFieldColumn.TabIndex = 3;
            this.lblFieldColumn.Text = "Field Column";
            // 
            // cmbFieldColumn
            // 
            this.cmbFieldColumn.FormattingEnabled = true;
            this.cmbFieldColumn.Location = new System.Drawing.Point(42, 247);
            this.cmbFieldColumn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cmbFieldColumn.Name = "cmbFieldColumn";
            this.cmbFieldColumn.Size = new System.Drawing.Size(363, 23);
            this.cmbFieldColumn.TabIndex = 4;
            this.cmbFieldColumn.SelectedIndexChanged += new System.EventHandler(this.cmbFieldColumn_SelectedIndexChanged);
            // 
            // cmbManuScriptColumn
            // 
            this.cmbManuScriptColumn.FormattingEnabled = true;
            this.cmbManuScriptColumn.Location = new System.Drawing.Point(42, 192);
            this.cmbManuScriptColumn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cmbManuScriptColumn.Name = "cmbManuScriptColumn";
            this.cmbManuScriptColumn.Size = new System.Drawing.Size(361, 23);
            this.cmbManuScriptColumn.TabIndex = 6;
            this.cmbManuScriptColumn.SelectedIndexChanged += new System.EventHandler(this.cmbManuScriptColumn_SelectedIndexChanged);
            // 
            // lblManuscriptColumn
            // 
            this.lblManuscriptColumn.AutoSize = true;
            this.lblManuscriptColumn.Location = new System.Drawing.Point(42, 175);
            this.lblManuscriptColumn.Name = "lblManuscriptColumn";
            this.lblManuscriptColumn.Size = new System.Drawing.Size(114, 15);
            this.lblManuscriptColumn.TabIndex = 5;
            this.lblManuscriptColumn.Text = "ManuScript Column";
            // 
            // btnValidate
            // 
            this.btnValidate.Location = new System.Drawing.Point(168, 291);
            this.btnValidate.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnValidate.Name = "btnValidate";
            this.btnValidate.Size = new System.Drawing.Size(100, 32);
            this.btnValidate.TabIndex = 7;
            this.btnValidate.Text = "Validate";
            this.btnValidate.UseVisualStyleBackColor = true;
            this.btnValidate.Click += new System.EventHandler(this.btnValidate_Click);
            // 
            // cmbSheetName
            // 
            this.cmbSheetName.FormattingEnabled = true;
            this.cmbSheetName.Location = new System.Drawing.Point(42, 134);
            this.cmbSheetName.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cmbSheetName.Name = "cmbSheetName";
            this.cmbSheetName.Size = new System.Drawing.Size(363, 23);
            this.cmbSheetName.TabIndex = 9;
            this.cmbSheetName.SelectedIndexChanged += new System.EventHandler(this.cmbSheetName_SelectedIndexChanged);
            // 
            // lblSheetName
            // 
            this.lblSheetName.AutoSize = true;
            this.lblSheetName.Location = new System.Drawing.Point(42, 116);
            this.lblSheetName.Name = "lblSheetName";
            this.lblSheetName.Size = new System.Drawing.Size(71, 15);
            this.lblSheetName.TabIndex = 8;
            this.lblSheetName.Text = "Sheet Name";
            // 
            // lblheader1
            // 
            this.lblheader1.AutoSize = true;
            this.lblheader1.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblheader1.Location = new System.Drawing.Point(149, 14);
            this.lblheader1.Name = "lblheader1";
            this.lblheader1.Size = new System.Drawing.Size(136, 25);
            this.lblheader1.TabIndex = 10;
            this.lblheader1.Text = "Field Unit Tester";
            // 
            // btnSettings
            // 
            this.btnSettings.Location = new System.Drawing.Point(354, 9);
            this.btnSettings.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnSettings.Name = "btnSettings";
            this.btnSettings.Size = new System.Drawing.Size(82, 22);
            this.btnSettings.TabIndex = 11;
            this.btnSettings.Text = "Settings";
            this.btnSettings.UseVisualStyleBackColor = true;
            this.btnSettings.Click += new System.EventHandler(this.btnSettings_Click);
            // 
            // ValidatorForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(465, 363);
            this.Controls.Add(this.btnSettings);
            this.Controls.Add(this.lblheader1);
            this.Controls.Add(this.cmbSheetName);
            this.Controls.Add(this.lblSheetName);
            this.Controls.Add(this.btnValidate);
            this.Controls.Add(this.cmbManuScriptColumn);
            this.Controls.Add(this.lblManuscriptColumn);
            this.Controls.Add(this.cmbFieldColumn);
            this.Controls.Add(this.lblFieldColumn);
            this.Controls.Add(this.btnBrowse);
            this.Controls.Add(this.lblPath);
            this.Controls.Add(this.txtPL101path);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "ValidatorForm";
            this.Text = "Field Validator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private TextBox txtPL101path;
        private Label lblPath;
        private Button btnBrowse;
        private Label lblFieldColumn;
        private ComboBox cmbFieldColumn;
        private ComboBox cmbManuScriptColumn;
        private Label lblManuscriptColumn;
        private Button btnValidate;
        private ComboBox cmbSheetName;
        private Label lblSheetName;
        private Label lblheader1;
        private Button btnSettings;
    }
}