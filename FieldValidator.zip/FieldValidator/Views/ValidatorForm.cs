
using OfficeOpenXml;
using System.Text;
using System.Xml;
using System.Xml.Linq;

namespace FieldValidator
{
    public partial class ValidatorForm : Form
    {
        public ValidatorForm()
        {
            InitializeComponent();
            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
            btnValidate.Enabled = false;
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            var openFile = new OpenFileDialog();
            openFile.Multiselect = false;

            DialogResult result = openFile.ShowDialog();
            if (result == DialogResult.OK)
            {
                txtPL101path.Text = openFile.FileName;
                // MessageBox.Show(fileName);
            }
        }

        private void enableValidateBtn()
        {
            if (txtPL101path.Text == "" || cmbSheetName.SelectedValue.ToString() == "0" || cmbFieldColumn.SelectedValue.ToString() == "0" || cmbManuScriptColumn.SelectedValue.ToString() == "0")
            {
                btnValidate.Enabled = false;
            }
            else { btnValidate.Enabled = true; }
        }

        private void txtPL101path_TextChanged(object sender, EventArgs e)
        {
            cmbSheetName.ValueMember = "ItemID";
            cmbSheetName.DisplayMember = "ItemName";
            cmbSheetName.DataSource = GetSheetList();
            enableValidateBtn();
        }

        private void cmbFieldColumn_SelectedIndexChanged(object sender, EventArgs e)
        {
            enableValidateBtn();
        }

        private void cmbManuScriptColumn_SelectedIndexChanged(object sender, EventArgs e)
        {
            enableValidateBtn();
        }

        public List<Items> GetColumnList()
        {

            List<Items> columnNames = new List<Items>();
            columnNames.Add(new Items { ItemID = 0, ItemName = "--Select--" });

            FileInfo fi = new FileInfo(txtPL101path.Text);

            //create a new Excel package in a memorystream
            if (fi.Exists)
            {
                using (ExcelPackage excelPackage = new ExcelPackage(fi))
                {
                    int sheetid = Convert.ToInt32(cmbSheetName.SelectedValue.ToString());
                    ExcelWorksheet worksheet = excelPackage.Workbook.Worksheets[sheetid];
                    //loop all columns in a row
                    for (int j = worksheet.Dimension.Start.Column; j <=
                    worksheet.Dimension.End.Column; j++)
                    {
                        //add the cell data to the List
                        if (worksheet.Cells[1, j].Value != null)
                        {
                            columnNames.Add(new Items { ItemID = j, ItemName = worksheet.Cells[1, j].Value.ToString() });
                        }
                    }
                }
            }

            return columnNames;
        }

        public List<Items> GetSheetList()
        {
            List<Items> sheetlist = new List<Items>();
            int count = 1;
            sheetlist.Add(new Items { ItemID = 0, ItemName = "--Select--" });

            //read the Excel file as byte array
            FileInfo fi = new FileInfo(txtPL101path.Text);

            //create a new Excel package in a memorystream
            if (fi.Exists)
            {
                using (ExcelPackage excelPackage = new ExcelPackage(fi))
                {
                    //loop all worksheets
                    count = 1;
                    foreach (ExcelWorksheet worksheet in excelPackage.Workbook.Worksheets)
                    {
                        sheetlist.Add(new Items { ItemID = count, ItemName = worksheet.Name });
                        count++;
                    }
                }
            }
            return sheetlist;
        }

        private void cmbSheetName_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbSheetName.SelectedValue.ToString() != "0")
            {
                cmbFieldColumn.ValueMember = "ItemID";
                cmbFieldColumn.DisplayMember = "ItemName";
                cmbFieldColumn.DataSource = GetColumnList();
                cmbManuScriptColumn.ValueMember = "ItemID";
                cmbManuScriptColumn.DisplayMember = "ItemName";
                cmbManuScriptColumn.DataSource = GetColumnList();
            }
            enableValidateBtn();
        }

        private void btnSettings_Click(object sender, EventArgs e)
        {
            this.Hide();
            new ConfigurationForm().Show();
        }

        private void btnValidate_Click(object sender, EventArgs e)
        {
            new ConfigurationForm().setConfigData();
            //read the Excel file as byte array
            FileInfo fi = new FileInfo(txtPL101path.Text);

            //create a new Excel package in a memorystream
            if (fi.Exists)
            {
                using (ExcelPackage excelPackage = new ExcelPackage(fi))
                {
                    //loop all worksheets
                    ExcelWorksheet worksheet = excelPackage.Workbook.Worksheets[Convert.ToInt32(cmbSheetName.SelectedValue)];
                    int fieldcol = Convert.ToInt32(cmbFieldColumn.SelectedValue);
                    int manuscriptcol = Convert.ToInt32(cmbManuScriptColumn.SelectedValue);
                    int commentscol = manuscriptcol + 2;
                    string comments = string.Empty;
                    string[] ValueOptions = { "Dropdown", "Radio", "Checkbox" };
                    string NotApplicable = "N/A";
                    IDictionary<string, string> columnNumbers = new Dictionary<string, string>();
                    string xPath = string.Empty;

                    XDocument doc = XDocument.Load("ColumnMapping.xml");
                    if (!(doc == null)) 
                    {
                       columnNumbers = doc.Root.Elements("add")
                                    .ToDictionary(c => c.Attribute("key").Value,
                                                  c => c.Attribute("value").Value);
                    }

                    //loop all rows except headers
                    for (int i = worksheet.Dimension.Start.Row + 1; i <= worksheet.Dimension.End.Row; i++)
                    {
                        try
                        {
                            string field = worksheet.Cells[i, fieldcol].Value != null ? Convert.ToString(worksheet.Cells[i, fieldcol].Value).Trim() : null;
                            string manuscript = worksheet.Cells[i, manuscriptcol].Value != null ? Convert.ToString(worksheet.Cells[i, manuscriptcol].Value).Trim() : null;

                            if (!string.IsNullOrEmpty(field) && !string.IsNullOrEmpty(manuscript))
                            {
                                XmlDocument xmlDoc = new ConfigurationForm().getFieldXML(field, manuscript);
                                string serverResponse = xmlDoc.InnerXml.ToString();

                                if (serverResponse.Contains("ManuScript.getFieldDetailRs status=\"failure\"")) {
                                    var temp = xmlDoc.GetElementsByTagName("ManuScript.getFieldDetailRs");
                                    comments += "Error : Either Manuscript or Field is not present \n";
                                    worksheet.Cells[i, commentscol].Value = comments;
                                    comments = string.Empty;
                                    continue;
                                }

                                //Fetch xPath of the field
                                if (xmlDoc.GetElementsByTagName("ManuScript.getFullPathRs").Count != 0)
                                {
                                    xPath = Convert.ToString(xmlDoc.SelectSingleNode("//ManuScript.getFullPathRs/@path").Value);
                                }

                                //To Check Field Caption
                                int CaptionColNum = Convert.ToInt32(columnNumbers["Caption"]);
                                string caption = (worksheet.Cells[i, CaptionColNum].Value != null ? Convert.ToString(worksheet.Cells[i, CaptionColNum].Value).Trim() : null);
                                if (!string.IsNullOrEmpty(caption) && caption != NotApplicable)
                                {
                                    if (xmlDoc.GetElementsByTagName("caption").Count == 0 || string.IsNullOrEmpty(xmlDoc.SelectSingleNode("//caption/@value").Value)
                                        || xmlDoc.SelectSingleNode("//caption/@value").Value == "x")
                                    {
                                        comments += "Caption not provided \n";
                                    }
                                }

                                //To check for Datatype of field
                                int DataTypeColNum = Convert.ToInt32(columnNumbers["DataType"]);
                                string datatype = (worksheet.Cells[i, DataTypeColNum].Value != null ? Convert.ToString(worksheet.Cells[i, DataTypeColNum].Value).ToLower().Trim() : null);
                                if (!string.IsNullOrEmpty(datatype) && datatype != NotApplicable)
                                {
                                    if (xmlDoc.SelectSingleNode("//public/@type").Value.ToLower() != datatype.Trim())
                                    {
                                        comments += "DataType not matching \n";
                                    }
                                }

                                //To Check Value of the field
                                int ValueColNum = Convert.ToInt32(columnNumbers["FieldValue"]);
                                string FieldValue = worksheet.Cells[i, ValueColNum].Value != null ? Convert.ToString(worksheet.Cells[i, ValueColNum].Value).Trim() : null;
                                string ValueComment = "Value is not provided \n";
                                if ((FieldValue != string.Empty) && (FieldValue != NotApplicable))
                                {
                                    //if value is dropdown
                                    if (ValueOptions.Contains(FieldValue) && (xmlDoc.GetElementsByTagName("options").Count == 0))
                                    {
                                        comments += ValueComment;
                                    }
                                    //if value is Calculation
                                    else if ((FieldValue == "Calculated" || FieldValue == "Calculation") &&
                                        (xmlDoc.GetElementsByTagName("calculation").Count == 0))
                                    {
                                        comments += ValueComment;
                                    }
                                    //if value is Conditional
                                    else if ((FieldValue == "Conditional") &&
                                       (xmlDoc.GetElementsByTagName("comparison").Count == 0))
                                    {
                                        comments += ValueComment;
                                    }
                                    //if value is Constant
                                    else if ((FieldValue == "Constant") &&
                                      (xmlDoc.GetElementsByTagName("value").Count == 0))
                                    {
                                        comments += ValueComment;
                                    }
                                    else if (xmlDoc.GetElementsByTagName("value").Count == 0 || string.IsNullOrEmpty(Convert.ToString(xmlDoc.SelectSingleNode("//value/@value").Value))
                                        || xmlDoc.SelectSingleNode("//value/@value").Value == "x")
                                    {
                                        comments += ValueComment;
                                    }
                                }

                                //To Check Field Default Value
                                int DefaultColNum = Convert.ToInt32(columnNumbers["Default"]);
                                string Default = (worksheet.Cells[i, DefaultColNum].Value != null ? Convert.ToString(worksheet.Cells[i, DefaultColNum].Value).Trim() : null);
                                if (!string.IsNullOrEmpty(Default) && Default != NotApplicable)
                                {
                                    if (xmlDoc.GetElementsByTagName("default").Count == 0 || string.IsNullOrEmpty(xmlDoc.SelectSingleNode("//default/@value").Value)
                                        || xmlDoc.SelectSingleNode("//default/@value").Value == "x")
                                    {
                                        comments += "Default value is not Set \n";
                                    }
                                }

                                //To Check Minimum
                                int MinColNum = Convert.ToInt32(columnNumbers["Minimum"]);
                                string Minimum = (worksheet.Cells[i, MinColNum].Value != null ? Convert.ToString(worksheet.Cells[i, MinColNum].Value).Trim() : null);
                                if (!string.IsNullOrEmpty(Minimum) && Minimum != NotApplicable)
                                {
                                    if (xmlDoc.GetElementsByTagName("minimum ").Count == 0 || string.IsNullOrEmpty(xmlDoc.SelectSingleNode("//minimum/@value").Value)
                                            || xmlDoc.SelectSingleNode("//minimum/@value").Value == "x")
                                    {
                                        comments += "Minimum is not Set \n";
                                    }
                                }

                                //To Check Maximum
                                int MaxColNum = Convert.ToInt32(columnNumbers["Maximum"]);
                                string Maximum = (worksheet.Cells[i, MaxColNum].Value != null ? Convert.ToString(worksheet.Cells[i, MaxColNum].Value).Trim() : null);
                                if (!string.IsNullOrEmpty(Maximum) && Maximum != NotApplicable)
                                {
                                    if (xmlDoc.GetElementsByTagName("maximum").Count == 0 || string.IsNullOrEmpty(xmlDoc.SelectSingleNode("//maximum/@value").Value)
                                            || xmlDoc.SelectSingleNode("//maximum/@value").Value == "x")
                                    {
                                        comments += "Maximum is not Set \n";
                                    }
                                }

                                //To Check Max Length
                                int MaxLenColNum = Convert.ToInt32(columnNumbers["MaxLength"]);
                                string MaxLength = (worksheet.Cells[i, MaxLenColNum].Value != null ? Convert.ToString(worksheet.Cells[i, MaxLenColNum].Value).Trim() : null);
                                if (!string.IsNullOrEmpty(MaxLength) && MaxLength != NotApplicable)
                                {
                                    if (xmlDoc.GetElementsByTagName("maxLength").Count == 0 || string.IsNullOrEmpty(xmlDoc.SelectSingleNode("//maxLength/@value").Value)
                                            || xmlDoc.SelectSingleNode("//maxLength/@value").Value == "x")
                                    {
                                        comments += "MaxLength is not Set \n";
                                    }
                                    else if (xmlDoc.SelectSingleNode("//maxLength/@value").Value != MaxLength)
                                    {
                                        comments += "Warning : Incorrect MaxLength is  Set \n";
                                    }
                                }

                                //To Check Format Mask
                                int FormatMaskColNum = Convert.ToInt32(columnNumbers["FormatMask"]);
                                string FormatMask = (worksheet.Cells[i, FormatMaskColNum].Value != null ? Convert.ToString(worksheet.Cells[i, FormatMaskColNum].Value).Trim() : null);
                                if (!string.IsNullOrEmpty(FormatMask) && FormatMask != NotApplicable)
                                {
                                    if (xmlDoc.GetElementsByTagName("formatMask").Count == 0 || string.IsNullOrEmpty(xmlDoc.SelectSingleNode("//formatMask/@value").Value)
                                            || xmlDoc.SelectSingleNode("//formatMask/@value").Value == "x")
                                    {
                                        comments += "Format Mask is not Set \n";
                                    }
                                }

                                //To Check Applicable\Hide
                                int HideShowColNum = Convert.ToInt32(columnNumbers["HideShow"]);
                                string HideShow = (worksheet.Cells[i, HideShowColNum].Value != null ? Convert.ToString(worksheet.Cells[i, HideShowColNum].Value).ToLower().Trim() : null);
                                if (!string.IsNullOrEmpty(HideShow) && HideShow != NotApplicable)
                                {
                                    if (xmlDoc.GetElementsByTagName("applicable").Count == 0 || string.IsNullOrEmpty(xmlDoc.SelectSingleNode("//applicable/@value").Value))
                                    {
                                        comments += "Show Hide Condition is not Set \n";
                                    }
                                    else if ((HideShow == "show" && xmlDoc.SelectSingleNode("//applicable/@value").Value == "1") ||
                                             (HideShow == "hide" && xmlDoc.SelectSingleNode("//applicable/@value").Value == "0"))
                                    {
                                    }
                                    else {

                                        comments += "Warning : Incorrect Applicable is set \n";
                                    }
                                }

                                //To Check Required flag
                                int ReqdColNum = Convert.ToInt32(columnNumbers["Required"]);
                                string Required = (worksheet.Cells[i, ReqdColNum].Value != null ? Convert.ToString(worksheet.Cells[i, ReqdColNum].Value).Trim() : null);
                                if (!string.IsNullOrEmpty(Required) && Required != NotApplicable)
                                {
                                    if (xmlDoc.GetElementsByTagName("required").Count == 0 || string.IsNullOrEmpty(xmlDoc.SelectSingleNode("//required/@value").Value))

                                    {
                                        comments += "Required Field is not Set \n";
                                    }
                                }

                                //To Check Read Only flag
                                int ReadOnlyColNum = Convert.ToInt32(columnNumbers["ReadOnly"]);
                                string ReadOnly = (worksheet.Cells[i, ReadOnlyColNum].Value != null ? Convert.ToString(worksheet.Cells[i, ReadOnlyColNum].Value).Trim() : null);
                                if (!string.IsNullOrEmpty(ReadOnly) && ReadOnly != NotApplicable)
                                {
                                    if (xmlDoc.GetElementsByTagName("readOnly").Count == 0 || string.IsNullOrEmpty(xmlDoc.SelectSingleNode("//readOnly/@value").Value))
                                    {
                                        comments += "ReadOnly Field is not Set \n";
                                    }
                                }

                                //To Check Annotations
                                int AnnColNum = Convert.ToInt32(columnNumbers["Annotations"]);
                                string Annotation = (worksheet.Cells[i, AnnColNum].Value != null ? Convert.ToString(worksheet.Cells[i, AnnColNum].Value).Trim() : null);
                                if (!string.IsNullOrEmpty(Annotation) && Annotation != NotApplicable)
                                {
                                    XmlDocument annotationsXml = new ConfigurationForm().getFieldAnnotationsXML(field, manuscript);
                                    if (annotationsXml.GetElementsByTagName("comment").Count == 0 || string.IsNullOrEmpty(annotationsXml.SelectSingleNode("//comment").InnerXml))
                                    {
                                        comments += "Annotation is not Set \n";
                                    }
                                    else if (annotationsXml.SelectSingleNode("//comment").InnerXml != Annotation)
                                    {
                                        comments += "Annotation are incorrect \n";
                                    }
                                }
                            }
                        }
                        catch (Exception ex) 
                        {
                            comments += "Error Occured " + ex.Message;
                        }

                        worksheet.Cells[i, commentscol].Value = comments;
                        comments = string.Empty;
                        worksheet.Cells[i, commentscol+1].Value = xPath;
                        xPath = string.Empty;
                    }
                    //Instead of converting to bytes, you could also use FileInfo
                    FileInfo fi1 = new FileInfo(txtPL101path.Text);
                    excelPackage.SaveAs(fi1);
                }
                MessageBox.Show("Validation Complete !!!! Please check comments in selected PL101");
            }
        }
    }

    public class Items
    {
        public Int64 ItemID { get; set; }
        public string ItemName { get; set; }
    }

}